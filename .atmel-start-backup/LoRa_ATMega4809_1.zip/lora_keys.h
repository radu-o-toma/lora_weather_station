/*
 * lora_keys.h
 *
 * Created: 3/7/2019 2:42:55 PM
 *  Author: m50653
 */ 


#ifndef LORA_KEYS_H_
#define LORA_KEYS_H_

//#define OTAA              1
#define ABP             1

#ifdef OTAA

const char my_deveui[] = "0004A30B002446E8";
const char my_appeui[] = "70B3D57ED001FBAE";
const char my_appkey[] = "49392013BF5F0B5DAD7BCC579A673AC8";

#elif ABP

const char my_devaddr[] = "260517E9";
const char my_nwkskey[] = "3502194504B44EE7325008E46EBBFF8F";
const char my_appskey[] = "1AF62A8672AC05E43B246CCCD6E0B970";

#endif

#endif /* LORA_KEYS_H_ */