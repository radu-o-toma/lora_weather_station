#include <atmel_start.h>
#include <string.h>
#include "lora_handling.h"
#include "low_power.h"
#include <util/delay.h>



char* sensor_data[15];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	sensor_data[0] = 0x41;
	sensor_data[1] = 0x30;

    LORA_HANDLING_loraInit();

    while (1)
    {
		
		//LOW_POWER_exitLowPower();
	
        
        LORA_HANDLING_transmit(sensor_data);
		
		if (sensor_data[0] == 0x30){
			sensor_data[0] = 0x41;
			sensor_data[1] = 0x30;
		} else {
			sensor_data[0] = 0x30;
			sensor_data[1] = 0x41;
		}
		

        //LOW_POWER_enterLowPower();
		for (uint16_t counter = 0; counter < 10; counter++)
			_delay_ms(1000);

    }

    return 0;
}
