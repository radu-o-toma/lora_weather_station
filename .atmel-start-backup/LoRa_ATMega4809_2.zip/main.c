#include <atmel_start.h>
#include <string.h>
#include "lora_handling.h"
#include "low_power.h"
#include <util/delay.h>

#include "i2c_simple_master.h"
#include "sht3x.h"

char* sensor_data[15];

#define COMMAND_LENGTH 2
char command[2];
char reply[10];
uint16_t temperature_reading;
uint16_t humidity_reading;
float temperature, humidity;


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	sensor_data[0] = 0x41;
	sensor_data[1] = 0x30;

    LORA_HANDLING_loraInit();
	
	command[0]=0xF3;
	command[1]=0x2D;
	
	_delay_ms(100); //  delay for SHT3x sensor
	
	I2C_MASTER_writeNBytes(SHT3X_ADDR, &command, COMMAND_LENGTH);
	_delay_ms(1); //  delay for SHT3x sensor
	I2C_MASTER_readNBytes(SHT3X_ADDR, &reply,3);
	
	command[0]=0x30;
	command[1]=0x41;
	
	I2C_MASTER_writeNBytes(SHT3X_ADDR, &command, COMMAND_LENGTH);
	_delay_ms(1); //  delay for SHT3x sensor
	I2C_MASTER_readNBytes(SHT3X_ADDR, &reply,3);

    while (1)
    {
		
		//LOW_POWER_exitLowPower();
	
        
        LORA_HANDLING_transmit(sensor_data);
		
		if (sensor_data[0] == 0x30){
			sensor_data[0] = 0x41;
			sensor_data[1] = 0x30;
		} else {
			sensor_data[0] = 0x30;
			sensor_data[1] = 0x41;
		}
		

        //LOW_POWER_enterLowPower();
		for (uint16_t counter = 0; counter < 10; counter++)
			_delay_ms(1000);

    }

    return 0;
}
